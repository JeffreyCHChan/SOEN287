//Maxime Giroux 40157483

function deleteRow(r) {
    var i = r.parentNode.parentNode.rowIndex;
    document.getElementById("userlist").deleteRow(i);
  }

